import type { AbstractIntlMessages } from "next-intl";
import { getRequestConfig } from "next-intl/server";
import { routing } from "./routing";

export default getRequestConfig(async ({ locale }) => {
  // Validate locale against routing.locales
  if (!routing.locales.includes(locale as any)) {
    throw new Error(`Unsupported locale: ${locale}`);
  }

  let messages: AbstractIntlMessages;
  try {
    messages = (await import(`../messages/${locale}.json`)).default;
  } catch {
    // Fallback to English messages if a file is missing.
    messages = (await import("../messages/en.json")).default;
  }

  return { messages, timeZone: "Europe/Warsaw" };
});
